package com.example.asind;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;

public class setting extends AppCompatActivity {
    private Button UpdateAccountSetting;
    private EditText userName,mobile,village,address;
    private ProgressDialog loadingBar;
    private String cuurentUserID;
    private FirebaseAuth mAuth;
    private DatabaseReference Rootref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        mAuth=FirebaseAuth.getInstance();
        cuurentUserID=mAuth.getCurrentUser().getUid();
        Rootref= FirebaseDatabase.getInstance().getReference();
        UpdateAccountSetting=(Button)findViewById(R.id.update_settings_button);
        userName=(EditText)findViewById(R.id.set_user_name);
        mobile=(EditText)findViewById(R.id.set_mobile_number);
        village=(EditText)findViewById(R.id.set_vlg);
        address=(EditText)findViewById(R.id.set_address);
        loadingBar=new ProgressDialog(this);
        UpdateAccountSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                udpadesetting();

            }
        });
        RetriveUserInfo();

    }
    private void udpadesetting() {




        if(TextUtils.isEmpty(userName.getText().toString()) )
        {
            Toast.makeText(this, "Please Write Your User Name...", Toast.LENGTH_SHORT).show();
        }
        if(TextUtils.isEmpty(mobile.getText().toString()) && TextUtils.isEmpty(village.getText().toString())&&TextUtils.isEmpty(address.getText().toString()))
        {
            Toast.makeText(this, "Please Enter your Deatial", Toast.LENGTH_SHORT).show();
        }
        else {
            HashMap<String, String> profileMap = new HashMap<>();
            profileMap.put("uid", cuurentUserID);
            profileMap.put("Village", village.getText().toString());
            profileMap.put("Address", address.getText().toString());
            profileMap.put("Name", userName.getText().toString());
            profileMap.put("Mobile", mobile.getText().toString());
//            Rootref.child("User").child(cuurentUserID).child("Name").setValue(userName);
//            Rootref.child("User").child(cuurentUserID).child("uid").setValue(cuurentUserID);
//            Rootref.child("User").child(cuurentUserID).child("Mobile").setValue(mobile);
//            Rootref.child("User").child(cuurentUserID).child("Village").setValue(village);
//            Rootref.child("User").child(cuurentUserID).child("Address").setValue(address);
            Rootref.child("User").child(cuurentUserID).setValue(profileMap)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(setting.this, "Profile Upadated Successfully...", Toast.LENGTH_SHORT).show();

                                finish();  SendUseToMainActivity();
                            } else {
                                String message = task.getException().toString();
                                Toast.makeText(setting.this, "Error: " + message, Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
            SendUseToMainActivity();
        }
    }


    private void RetriveUserInfo(){
        Rootref.child("User").child(cuurentUserID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if((dataSnapshot.exists()) && (dataSnapshot.hasChild("Name"))&&(dataSnapshot.exists()) && (dataSnapshot.hasChild("Mobile"))&&(dataSnapshot.exists()) && (dataSnapshot.hasChild("Village"))){

                    String retriveUserName=dataSnapshot.child("Name").getValue().toString();
                    String retrivemobile=dataSnapshot.child("Mobile").getValue().toString();
                    String retrivevillage=dataSnapshot.child("Village").getValue().toString();
                    String retriveaddress=dataSnapshot.child("Address").getValue().toString();

                    userName.setText(retriveUserName);
                    mobile.setText(retrivemobile);
                    village.setText(retrivevillage);
                    address.setText(retriveaddress);
                }
                else
                {
                    Toast.makeText(setting.this, "Please Set and Update Your Profile..", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
    private void SendUseToMainActivity() {
        Intent mainIntent =new Intent(setting.this,MainActivity.class);
        mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(mainIntent);
        finish();
    }
}
